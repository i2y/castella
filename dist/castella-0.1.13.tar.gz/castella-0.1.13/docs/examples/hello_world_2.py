from castella import App, Text
from castella.frame import Frame

App(Frame("Hello world2", 480, 300), Text("Hello World!", font_size=20)).run()
