# Diff Summary

Date : 2022-09-03 13:11:19

Directory c:\\Users\\i2y\\ui\\cattt

Total : 6 files,  115 codes, 0 comments, 1 blanks, all 116 lines

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Python | 4 | 139 | 0 | 17 | 156 |
| HTML | 1 | 2 | 0 | 0 | 2 |
| Markdown | 1 | -26 | 0 | -16 | -42 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 6 | 115 | 0 | 1 | 116 |
| castella | 3 | 119 | 0 | 15 | 134 |
| docs | 1 | -26 | 0 | -16 | -42 |
| examples | 2 | 22 | 0 | 2 | 24 |

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)