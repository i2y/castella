# Summary

Date : 2022-09-03 13:11:19

Directory c:\\Users\\i2y\\ui\\cattt

Total : 69 files,  5967 codes, 43 comments, 1190 blanks, all 7200 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Python | 45 | 4,816 | 43 | 981 | 5,840 |
| TOML | 2 | 673 | 0 | 63 | 736 |
| Markdown | 14 | 262 | 0 | 119 | 381 |
| HTML | 2 | 122 | 0 | 25 | 147 |
| YAML | 2 | 66 | 0 | 2 | 68 |
| XML | 4 | 28 | 0 | 0 | 28 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 69 | 5,967 | 43 | 1,190 | 7,200 |
| .github | 1 | 16 | 0 | 1 | 17 |
| .github\\workflows | 1 | 16 | 0 | 1 | 17 |
| .idea | 4 | 28 | 0 | 0 | 28 |
| .idea\\inspectionProfiles | 1 | 6 | 0 | 0 | 6 |
| castella | 23 | 4,159 | 42 | 817 | 5,018 |
| docs | 13 | 209 | 0 | 94 | 303 |
| examples | 23 | 736 | 1 | 177 | 914 |
| tools | 1 | 43 | 0 | 12 | 55 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)