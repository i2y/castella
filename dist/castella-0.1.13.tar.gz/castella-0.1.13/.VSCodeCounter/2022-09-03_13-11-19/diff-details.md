# Diff Details

Date : 2022-09-03 13:11:19

Directory c:\\Users\\i2y\\ui\\cattt

Total : 6 files,  115 codes, 0 comments, 1 blanks, all 116 lines

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [castella/__init__.py](/castella/__init__.py) | Python | 1 | 0 | 0 | 1 |
| [castella/checkbox.py](/castella/checkbox.py) | Python | 105 | 0 | 15 | 120 |
| [castella/core.py](/castella/core.py) | Python | 13 | 0 | 0 | 13 |
| [docs/layout.md](/docs/layout.md) | Markdown | -26 | 0 | -16 | -42 |
| [examples/checkboxes.py](/examples/checkboxes.py) | Python | 20 | 0 | 2 | 22 |
| [examples/misc.html](/examples/misc.html) | HTML | 2 | 0 | 0 | 2 |

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details