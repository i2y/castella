# Diff Details

Date : 2022-09-23 18:51:01

Directory c:\\Users\\i2y\\ui\\cattt

Total : 5 files,  33 codes, 4 comments, 12 blanks, all 49 lines

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [castella/core.py](/castella/core.py) | Python | 13 | 4 | 4 | 21 |
| [castella/glfw_frame.py](/castella/glfw_frame.py) | Python | 6 | 0 | 2 | 8 |
| [castella/sdl_frame.py](/castella/sdl_frame.py) | Python | 5 | 0 | 2 | 7 |
| [castella/web_frame.py](/castella/web_frame.py) | Python | 12 | 0 | 4 | 16 |
| [examples/copy_and_paste.py](/examples/copy_and_paste.py) | Python | -3 | 0 | 0 | -3 |

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details