# Summary

Date : 2022-09-23 18:51:01

Directory c:\\Users\\i2y\\ui\\cattt

Total : 78 files,  6420 codes, 48 comments, 1296 blanks, all 7764 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Python | 53 | 5,262 | 48 | 1,087 | 6,397 |
| TOML | 2 | 673 | 0 | 63 | 736 |
| Markdown | 14 | 262 | 0 | 119 | 381 |
| HTML | 3 | 129 | 0 | 25 | 154 |
| YAML | 2 | 66 | 0 | 2 | 68 |
| XML | 4 | 28 | 0 | 0 | 28 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 78 | 6,420 | 48 | 1,296 | 7,764 |
| .github | 1 | 16 | 0 | 1 | 17 |
| .github\\workflows | 1 | 16 | 0 | 1 | 17 |
| .idea | 4 | 28 | 0 | 0 | 28 |
| .idea\\inspectionProfiles | 1 | 6 | 0 | 0 | 6 |
| castella | 27 | 4,470 | 47 | 900 | 5,417 |
| docs | 13 | 209 | 0 | 94 | 303 |
| examples | 28 | 878 | 1 | 200 | 1,079 |
| tools | 1 | 43 | 0 | 12 | 55 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)