# Diff Summary

Date : 2022-09-23 18:51:01

Directory c:\\Users\\i2y\\ui\\cattt

Total : 5 files,  33 codes, 4 comments, 12 blanks, all 49 lines

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Python | 5 | 33 | 4 | 12 | 49 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 5 | 33 | 4 | 12 | 49 |
| castella | 4 | 36 | 4 | 12 | 52 |
| examples | 1 | -3 | 0 | 0 | -3 |

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)