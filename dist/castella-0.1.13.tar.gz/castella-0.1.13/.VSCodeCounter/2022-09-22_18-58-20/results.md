# Summary

Date : 2022-09-22 18:58:20

Directory c:\\Users\\i2y\\ui\\cattt

Total : 78 files,  6387 codes, 44 comments, 1284 blanks, all 7715 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Python | 53 | 5,229 | 44 | 1,075 | 6,348 |
| TOML | 2 | 673 | 0 | 63 | 736 |
| Markdown | 14 | 262 | 0 | 119 | 381 |
| HTML | 3 | 129 | 0 | 25 | 154 |
| YAML | 2 | 66 | 0 | 2 | 68 |
| XML | 4 | 28 | 0 | 0 | 28 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 78 | 6,387 | 44 | 1,284 | 7,715 |
| .github | 1 | 16 | 0 | 1 | 17 |
| .github\\workflows | 1 | 16 | 0 | 1 | 17 |
| .idea | 4 | 28 | 0 | 0 | 28 |
| .idea\\inspectionProfiles | 1 | 6 | 0 | 0 | 6 |
| castella | 27 | 4,434 | 43 | 888 | 5,365 |
| docs | 13 | 209 | 0 | 94 | 303 |
| examples | 28 | 881 | 1 | 200 | 1,082 |
| tools | 1 | 43 | 0 | 12 | 55 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)