# Details

Date : 2022-09-22 18:58:20

Directory c:\\Users\\i2y\\ui\\cattt

Total : 78 files,  6387 codes, 44 comments, 1284 blanks, all 7715 lines

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [.github/workflows/ci.yml](/.github/workflows/ci.yml) | YAML | 16 | 0 | 1 | 17 |
| [.idea/cattt.iml](/.idea/cattt.iml) | XML | 8 | 0 | 0 | 8 |
| [.idea/inspectionProfiles/profiles_settings.xml](/.idea/inspectionProfiles/profiles_settings.xml) | XML | 6 | 0 | 0 | 6 |
| [.idea/modules.xml](/.idea/modules.xml) | XML | 8 | 0 | 0 | 8 |
| [.idea/vcs.xml](/.idea/vcs.xml) | XML | 6 | 0 | 0 | 6 |
| [README.md](/README.md) | Markdown | 53 | 0 | 25 | 78 |
| [castella/__init__.py](/castella/__init__.py) | Python | 16 | 0 | 2 | 18 |
| [castella/async_net_image.py](/castella/async_net_image.py) | Python | 36 | 0 | 9 | 45 |
| [castella/bar_chart.py](/castella/bar_chart.py) | Python | 63 | 0 | 15 | 78 |
| [castella/box.py](/castella/box.py) | Python | 302 | 0 | 40 | 342 |
| [castella/button.py](/castella/button.py) | Python | 184 | 0 | 25 | 209 |
| [castella/canvaskit_painter.py](/castella/canvaskit_painter.py) | Python | 164 | 0 | 41 | 205 |
| [castella/checkbox.py](/castella/checkbox.py) | Python | 127 | 0 | 15 | 142 |
| [castella/color.py](/castella/color.py) | Python | 361 | 2 | 7 | 370 |
| [castella/column.py](/castella/column.py) | Python | 232 | 0 | 36 | 268 |
| [castella/core.py](/castella/core.py) | Python | 1,196 | 1 | 342 | 1,539 |
| [castella/frame.py](/castella/frame.py) | Python | 16 | 0 | 5 | 21 |
| [castella/glfw_frame.py](/castella/glfw_frame.py) | Python | 184 | 1 | 41 | 226 |
| [castella/image.py](/castella/image.py) | Python | 32 | 0 | 8 | 40 |
| [castella/input.py](/castella/input.py) | Python | 179 | 1 | 31 | 211 |
| [castella/line_chart.py](/castella/line_chart.py) | Python | 53 | 0 | 14 | 67 |
| [castella/multiline_text.py](/castella/multiline_text.py) | Python | 103 | 2 | 15 | 120 |
| [castella/net_image.py](/castella/net_image.py) | Python | 34 | 0 | 8 | 42 |
| [castella/numpy_image.py](/castella/numpy_image.py) | Python | 72 | 0 | 15 | 87 |
| [castella/pie_chart.py](/castella/pie_chart.py) | Python | 58 | 0 | 15 | 73 |
| [castella/radio_buttons.py](/castella/radio_buttons.py) | Python | 46 | 1 | 12 | 59 |
| [castella/row.py](/castella/row.py) | Python | 232 | 0 | 36 | 268 |
| [castella/sdl_frame.py](/castella/sdl_frame.py) | Python | 200 | 0 | 41 | 241 |
| [castella/skia_painter.py](/castella/skia_painter.py) | Python | 186 | 0 | 51 | 237 |
| [castella/spacer.py](/castella/spacer.py) | Python | 25 | 0 | 8 | 33 |
| [castella/switch.py](/castella/switch.py) | Python | 79 | 0 | 13 | 92 |
| [castella/text.py](/castella/text.py) | Python | 119 | 0 | 15 | 134 |
| [castella/web_frame.py](/castella/web_frame.py) | Python | 135 | 35 | 28 | 198 |
| [docs/chart.md](/docs/chart.md) | Markdown | 0 | 0 | 1 | 1 |
| [docs/component.md](/docs/component.md) | Markdown | 0 | 0 | 1 | 1 |
| [docs/getting-started.md](/docs/getting-started.md) | Markdown | 126 | 0 | 44 | 170 |
| [docs/hello-world.md](/docs/hello-world.md) | Markdown | 45 | 0 | 28 | 73 |
| [docs/hot-reloading.md](/docs/hot-reloading.md) | Markdown | 0 | 0 | 1 | 1 |
| [docs/hot-restarting.md](/docs/hot-restarting.md) | Markdown | 0 | 0 | 1 | 1 |
| [docs/index.md](/docs/index.md) | Markdown | 19 | 0 | 8 | 27 |
| [docs/layout.md](/docs/layout.md) | Markdown | 0 | 0 | 1 | 1 |
| [docs/license.md](/docs/license.md) | Markdown | 18 | 0 | 5 | 23 |
| [docs/packaging.md](/docs/packaging.md) | Markdown | 1 | 0 | 1 | 2 |
| [docs/state.md](/docs/state.md) | Markdown | 0 | 0 | 1 | 1 |
| [docs/stateful-component.md](/docs/stateful-component.md) | Markdown | 0 | 0 | 1 | 1 |
| [docs/widgets.md](/docs/widgets.md) | Markdown | 0 | 0 | 1 | 1 |
| [examples/calc.py](/examples/calc.py) | Python | 85 | 0 | 20 | 105 |
| [examples/charts.py](/examples/charts.py) | Python | 56 | 0 | 10 | 66 |
| [examples/checkboxes.py](/examples/checkboxes.py) | Python | 20 | 0 | 2 | 22 |
| [examples/checkboxes_ja.py](/examples/checkboxes_ja.py) | Python | 21 | 0 | 4 | 25 |
| [examples/clock.py](/examples/clock.py) | Python | 19 | 0 | 8 | 27 |
| [examples/copy_and_paste.py](/examples/copy_and_paste.py) | Python | 34 | 0 | 6 | 40 |
| [examples/counter.html](/examples/counter.html) | HTML | 36 | 0 | 10 | 46 |
| [examples/counter.py](/examples/counter.py) | Python | 19 | 0 | 8 | 27 |
| [examples/counter_with_custom_state.py](/examples/counter_with_custom_state.py) | Python | 28 | 0 | 11 | 39 |
| [examples/counter_with_lock.py](/examples/counter_with_lock.py) | Python | 42 | 0 | 8 | 50 |
| [examples/counter_yet_another_version.py](/examples/counter_yet_another_version.py) | Python | 15 | 0 | 6 | 21 |
| [examples/generator.py](/examples/generator.py) | Python | 38 | 0 | 12 | 50 |
| [examples/hello_world.py](/examples/hello_world.py) | Python | 3 | 0 | 2 | 5 |
| [examples/layer.py](/examples/layer.py) | Python | 39 | 0 | 3 | 42 |
| [examples/layout_examples.py](/examples/layout_examples.py) | Python | 10 | 0 | 2 | 12 |
| [examples/layout_examples_with_flex.py](/examples/layout_examples_with_flex.py) | Python | 10 | 0 | 2 | 12 |
| [examples/layout_examples_with_scrollbar.py](/examples/layout_examples_with_scrollbar.py) | Python | 20 | 0 | 2 | 22 |
| [examples/misc.html](/examples/misc.html) | HTML | 86 | 0 | 15 | 101 |
| [examples/misc.py](/examples/misc.py) | Python | 53 | 0 | 11 | 64 |
| [examples/misc2.py](/examples/misc2.py) | Python | 65 | 0 | 12 | 77 |
| [examples/numpy_array.py](/examples/numpy_array.py) | Python | 39 | 1 | 9 | 49 |
| [examples/radio_buttons.py](/examples/radio_buttons.py) | Python | 6 | 0 | 2 | 8 |
| [examples/sizepolicy_examples.py](/examples/sizepolicy_examples.py) | Python | 20 | 0 | 2 | 22 |
| [examples/sizepolicy_examples_with_syntax_sugar.py](/examples/sizepolicy_examples_with_syntax_sugar.py) | Python | 14 | 0 | 2 | 16 |
| [examples/temp_conv.py](/examples/temp_conv.py) | Python | 35 | 0 | 13 | 48 |
| [examples/test.html](/examples/test.html) | HTML | 7 | 0 | 0 | 7 |
| [examples/triple_counter.py](/examples/triple_counter.py) | Python | 28 | 0 | 9 | 37 |
| [examples/triple_counter_with_complex_layout.py](/examples/triple_counter_with_complex_layout.py) | Python | 33 | 0 | 9 | 42 |
| [mkdocs.yml](/mkdocs.yml) | YAML | 50 | 0 | 1 | 51 |
| [poetry.lock](/poetry.lock) | TOML | 637 | 0 | 58 | 695 |
| [pyproject.toml](/pyproject.toml) | TOML | 36 | 0 | 5 | 41 |
| [tools/hot_restarter.py](/tools/hot_restarter.py) | Python | 43 | 0 | 12 | 55 |

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)