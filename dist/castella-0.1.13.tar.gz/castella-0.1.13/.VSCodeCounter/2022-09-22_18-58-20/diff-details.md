# Diff Details

Date : 2022-09-22 18:58:20

Directory c:\\Users\\i2y\\ui\\cattt

Total : 11 files,  154 codes, 1 comments, 33 blanks, all 188 lines

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [castella/__init__.py](/castella/__init__.py) | Python | -2 | 0 | 0 | -2 |
| [castella/checkbox.py](/castella/checkbox.py) | Python | 22 | 0 | 0 | 22 |
| [castella/core.py](/castella/core.py) | Python | 13 | 0 | 8 | 21 |
| [castella/glfw_frame.py](/castella/glfw_frame.py) | Python | 4 | 0 | 2 | 6 |
| [castella/radio_buttons.py](/castella/radio_buttons.py) | Python | 46 | 1 | 12 | 59 |
| [castella/sdl_frame.py](/castella/sdl_frame.py) | Python | 4 | 0 | 2 | 6 |
| [examples/charts.py](/examples/charts.py) | Python | -1 | 0 | 0 | -1 |
| [examples/copy_and_paste.py](/examples/copy_and_paste.py) | Python | 34 | 0 | 6 | 40 |
| [examples/layer.py](/examples/layer.py) | Python | 21 | 0 | 1 | 22 |
| [examples/radio_buttons.py](/examples/radio_buttons.py) | Python | 6 | 0 | 2 | 8 |
| [examples/test.html](/examples/test.html) | HTML | 7 | 0 | 0 | 7 |

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details