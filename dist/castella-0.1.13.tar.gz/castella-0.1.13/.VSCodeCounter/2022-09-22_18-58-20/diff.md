# Diff Summary

Date : 2022-09-22 18:58:20

Directory c:\\Users\\i2y\\ui\\cattt

Total : 11 files,  154 codes, 1 comments, 33 blanks, all 188 lines

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Python | 10 | 147 | 1 | 33 | 181 |
| HTML | 1 | 7 | 0 | 0 | 7 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 11 | 154 | 1 | 33 | 188 |
| castella | 6 | 87 | 1 | 24 | 112 |
| examples | 5 | 67 | 0 | 9 | 76 |

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)