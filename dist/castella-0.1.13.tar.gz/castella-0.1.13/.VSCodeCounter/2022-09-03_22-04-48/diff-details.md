# Diff Details

Date : 2022-09-03 22:04:48

Directory c:\\Users\\i2y\\ui\\cattt

Total : 8 files,  266 codes, 0 comments, 61 blanks, all 327 lines

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [castella/__init__.py](/castella/__init__.py) | Python | 3 | 0 | 0 | 3 |
| [castella/bar_chart.py](/castella/bar_chart.py) | Python | 63 | 0 | 15 | 78 |
| [castella/core.py](/castella/core.py) | Python | 9 | 0 | 3 | 12 |
| [castella/line_chart.py](/castella/line_chart.py) | Python | 53 | 0 | 14 | 67 |
| [castella/pie_chart.py](/castella/pie_chart.py) | Python | 58 | 0 | 15 | 73 |
| [castella/skia_painter.py](/castella/skia_painter.py) | Python | 2 | 0 | 0 | 2 |
| [examples/charts.py](/examples/charts.py) | Python | 57 | 0 | 10 | 67 |
| [examples/checkboxes_ja.py](/examples/checkboxes_ja.py) | Python | 21 | 0 | 4 | 25 |

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details