# Diff Summary

Date : 2022-09-03 22:04:48

Directory c:\\Users\\i2y\\ui\\cattt

Total : 8 files,  266 codes, 0 comments, 61 blanks, all 327 lines

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Python | 8 | 266 | 0 | 61 | 327 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 8 | 266 | 0 | 61 | 327 |
| castella | 6 | 188 | 0 | 47 | 235 |
| examples | 2 | 78 | 0 | 14 | 92 |

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)