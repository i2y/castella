# Summary

Date : 2022-09-03 22:04:48

Directory c:\\Users\\i2y\\ui\\cattt

Total : 74 files,  6233 codes, 43 comments, 1251 blanks, all 7527 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Python | 50 | 5,082 | 43 | 1,042 | 6,167 |
| TOML | 2 | 673 | 0 | 63 | 736 |
| Markdown | 14 | 262 | 0 | 119 | 381 |
| HTML | 2 | 122 | 0 | 25 | 147 |
| YAML | 2 | 66 | 0 | 2 | 68 |
| XML | 4 | 28 | 0 | 0 | 28 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 74 | 6,233 | 43 | 1,251 | 7,527 |
| .github | 1 | 16 | 0 | 1 | 17 |
| .github\\workflows | 1 | 16 | 0 | 1 | 17 |
| .idea | 4 | 28 | 0 | 0 | 28 |
| .idea\\inspectionProfiles | 1 | 6 | 0 | 0 | 6 |
| castella | 26 | 4,347 | 42 | 864 | 5,253 |
| docs | 13 | 209 | 0 | 94 | 303 |
| examples | 25 | 814 | 1 | 191 | 1,006 |
| tools | 1 | 43 | 0 | 12 | 55 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)